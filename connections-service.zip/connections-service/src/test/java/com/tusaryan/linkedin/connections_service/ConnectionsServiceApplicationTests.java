package com.tusaryan.linkedin.connections_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
